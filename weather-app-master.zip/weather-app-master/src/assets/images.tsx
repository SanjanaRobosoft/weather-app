export { default as favicon } from './images/icons8-favorite-32.png';
export { default as faviYellow } from './images/icon_favourite_Active.svg';
export { default as tempIcon } from './images/icon_temperature_info.svg';
export { default as humidityIcon } from './images/icon_humidity_info.svg';
export { default as precipitationIcon } from './images/icon_precipitation_info.svg';
export { default as windIcon } from './images/icon_wind_info.svg';
export { default as visibilityIcon } from './images/icon_visibility_info.svg';
export {default as noFav}  from "./images/icon_nothing.svg";
export {default as logo}  from './images/logo_web.png';


