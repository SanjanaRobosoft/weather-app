export const BASE_URL ="https://api.openweathermap.org/data/2.5/weather"
